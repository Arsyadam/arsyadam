<footer class="bg-dark w-full rounded-t-xl">
test
</footer>